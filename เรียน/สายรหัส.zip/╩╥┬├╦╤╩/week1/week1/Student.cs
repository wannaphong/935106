﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace week1
{
    class Student
    {
        public string name;
        public string nickname;
        public string program;
        public string[] younger_person;
        public string[] elder_person;
        public string year;
    }
}
