/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ass2.pkg3_603410214.pkg3;

/**
 *
 * @author wannaphong
 */
public class HolyAngemon_Priest_Mode { // ประกาศ class ชื่อ HolyAngemon_Priest_Mode
    String name="HolyAngemon"; // ใช้เก็บชื่อ HolyAngemon
    int HP_HA_P_M=2000; // ใช้เก็บ HP ของ HolyAngemon
    public int getHP(){ // ใช้คืนค่าพลัง HP ของ HolyAngemon
        return HP_HA_P_M; // คืนค่า HP ปัจจุบันของ HolyAngemon
    }
}
