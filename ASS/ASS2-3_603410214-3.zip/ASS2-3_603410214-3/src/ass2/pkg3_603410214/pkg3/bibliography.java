/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ass2.pkg3_603410214.pkg3;

/**
 *
 * @author wannaphong
 */
public class bibliography { // ประกาศ class ชื่อ bibliography เป็นแบบพิมพ์ class ในการสร้างบรรณานุกรม
    String Author; // ใช้เก็บ ชื่อผู้แต่ง
    String Years; // ใช้เก็บ ปีที่พิมพ์
    String Book_Name; // ใช้เก็บ ชื่อหนังสือ
    String times; // ใช้เก็บ พิมพ์ครั้งที่
    String Place; // ใช้เก็บ สถานที่พิมพ์
    String Publisher; // ใช้เก็บ สำนักพิมพ์
}
