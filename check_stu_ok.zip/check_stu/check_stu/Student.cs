﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace check_stu
{
    public class Student
    {
        public String student_id;
        public String student_name;
    }
}
